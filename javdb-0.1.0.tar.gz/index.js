'use strict';
/**
 * JAVDB —— metadata + home 双角色插件。
 *
 * 数据策略（铁律：不编数据）：
 *  - 优先直连 javdb.com（搜索 / 详情 / 榜单）；该站有 Cloudflare 保护，
 *    机房 IP 常被 403，此时如实抛 CF_BLOCKED。
 *  - 搜索与详情在 javdb.com 不可用时，降级到 https://www.javdatabase.com
 *   （已实测可直连：搜索 ?s=番号、详情 /movies/{番号小写}/）。
 *  - 榜单（日/周/月排行）只有 javdb.com 有，被墙就如实失败，不拿"最新"冒充排行。
 *
 * 番号即条目 id（entryId），形如 SSIS-001；series=false（电影式）。
 *
 * ctx: types / type / id / dataDir / log(...) / hostCall(...)
 */
const fs = require('fs');
const path = require('path');

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36';
const TIMEOUT_MS = 18000;
const DOMAIN = 'javdb';

/* ---------------- 设置（插件自己存自己管） ---------------- */
function readSettings(ctx) {
  try {
    return JSON.parse(fs.readFileSync(path.join(ctx.dataDir, 'settings.json'), 'utf8'));
  } catch {
    return {};
  }
}
function writeSettings(ctx, obj) {
  fs.mkdirSync(ctx.dataDir, { recursive: true });
  fs.writeFileSync(path.join(ctx.dataDir, 'settings.json'), JSON.stringify(obj, null, 2));
}
function baseUrl(cfg) {
  return String(cfg.baseUrl || 'https://javdb.com').replace(/\/+$/, '');
}
function mirrorUrl(cfg) {
  return String(cfg.mirrorUrl || 'https://www.javdatabase.com').replace(/\/+$/, '');
}

/* ---------------- 通用请求 ---------------- */
function err(code, message) {
  const e = new Error(message);
  e.code = code;
  return e;
}
async function fetchText(url, referer) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), TIMEOUT_MS);
  try {
    const res = await fetch(url, {
      signal: ctrl.signal,
      redirect: 'follow',
      headers: {
        'User-Agent': UA,
        Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8,ja;q=0.7',
        ...(referer ? { Referer: referer } : {}),
      },
    });
    const text = await res.text();
    return { status: res.status, text };
  } catch (e) {
    const ee = err('FETCH_FAILED', '请求失败: ' + url + ' (' + (e.cause ? e.cause.code || e.cause.message : e.message) + ')');
    throw ee;
  } finally {
    clearTimeout(timer);
  }
}
function isCfBlock(status, text) {
  return status === 403 && /Attention Required|cf-chl|__cf_bm|challenge-platform/i.test(text);
}
function cfErr(url) {
  return err('CF_BLOCKED', 'javdb.com 被 Cloudflare 拦截（机房 IP 常见），换网络或稍后重试: ' + url);
}
function normCode(s) {
  return String(s || '').trim().toUpperCase();
}
function slugOf(code) {
  return normCode(code).toLowerCase();
}

/* ---------------- javdb.com 解析（主源，能通时用） ---------------- */
// 搜索页：https://javdb.com/search?q=SSIS-001&f=all
function parseJavdbSearch(html) {
  const out = [];
  const seen = new Set();
  // 卡片：<a href="/v/xxxxx"> + 标题 .video-title + 封面 img
  const re = /<a[^>]+href="(\/v\/[A-Za-z0-9]+)"[^>]*>([\s\S]{0,2500}?)(?:<\/a>)/g;
  let m;
  while ((m = re.exec(html)) !== null) {
    const vcode = m[1];
    if (seen.has(vcode)) continue;
    seen.add(vcode);
    const block = m[2];
    const t = block.match(/class="[^"]*video-title[^"]*"[^>]*>([^<]+)</)
      || block.match(/title="([^"]+)"/);
    const img = block.match(/<img[^>]+src="([^"]+)"/);
    const title = t ? t[1].trim() : vcode;
    // 从标题里抠番号
    const codeM = title.match(/([A-Za-z]{2,6}-\d{2,5})/);
    out.push({
      vcode,
      code: codeM ? normCode(codeM[1]) : '',
      title,
      poster: img ? img[1] : '',
    });
    if (out.length >= 30) break;
  }
  return out;
}
// 榜单页：https://javdb.com/rankings/daily|weekly|monthly
function parseJavdbRanking(html) {
  const out = [];
  const seen = new Set();
  const re = /<a[^>]+href="(\/v\/[A-Za-z0-9]+)"[^>]*>([\s\S]{0,3000}?)(?:<\/a>)/g;
  let m;
  while ((m = re.exec(html)) !== null) {
    const vcode = m[1];
    if (seen.has(vcode)) continue;
    seen.add(vcode);
    const block = m[2];
    const t = block.match(/class="[^"]*(?:video-title|movie-title)[^"]*"[^>]*>([^<]+)</)
      || block.match(/title="([^"]+)"/);
    const img = block.match(/<img[^>]+(?:data-src|src)="([^"]+)"/);
    const title = t ? t[1].trim() : vcode;
    const codeM = title.match(/([A-Za-z]{2,6}-\d{2,5})/);
    const d = block.match(/(\d{4})-(\d{2})-(\d{2})/);
    out.push({
      id: 'javdb_movie_' + vcode.replace('/v/', ''),
      code: codeM ? normCode(codeM[1]) : '',
      title,
      year: d ? Number(d[1]) : 0,
      poster: img ? absUrl(img[1], 'https://javdb.com') : '',
    });
    if (out.length >= 60) break;
  }
  return out;
}
function absUrl(u, base) {
  if (!u) return '';
  if (/^https?:\/\//i.test(u)) return u;
  if (u.startsWith('//')) return 'https:' + u;
  if (u.startsWith('/')) return base + u;
  return base + '/' + u;
}

/* ---------------- javdatabase.com 解析（降级源，已实测） ---------------- */
function parseJdbSearch(html, base) {
  const out = [];
  const seen = new Set();
  // 卡片结构：<a href=".../movies/{slug}/" class="cut-text">TITLE</a> + img
  const re = /<div class="card h-100 borderlesscard">([\s\S]*?)<\/div>\s*<\/div>\s*<\/div>/g;
  let m;
  while ((m = re.exec(html)) !== null) {
    const block = m[1];
    const link = block.match(/href="(https?:\/\/[^"]*\/movies\/([a-z0-9-]+)\/)"/);
    if (!link || seen.has(link[2])) continue;
    seen.add(link[2]);
    const titleM = block.match(/class="cut-text"[^>]*>\s*([^<]+?)\s*</);
    const imgM = block.match(/<img[^>]+src="([^"]+)"/);
    out.push({
      slug: link[2],
      code: normCode(link[2]),
      title: titleM ? titleM[1].trim() : normCode(link[2]),
      poster: imgM ? absUrl(imgM[1], base) : '',
    });
    if (out.length >= 30) break;
  }
  return out;
}
function parseJdbDetail(html, base, code) {
  const pick = (re) => {
    const m = html.match(re);
    return m ? m[1].trim() : '';
  };
  const ogImage = pick(/<meta property="og:image" content="([^"]+)"/);
  const h1 = pick(/<h1[^>]*>([^<]+)/);
  let title = h1;
  const dash = h1.indexOf(' - ');
  const shortTitle = dash > 0 ? h1.slice(dash + 3).trim() : h1;
  if (dash > 0) title = normCode(code) + ' ' + shortTitle;
  const dateStr = pick(/Release Date:\s*<\/b>\s*([\d-]{10})/);
  const year = dateStr ? dateStr.slice(0, 4) : '';
  // 演员：Actress(es): 之后 idols 链接
  const actress = [];
  const aSec = html.split('Actress(es):')[1];
  if (aSec) {
    const seg = aSec.slice(0, 1200);
    const re = /<a href="https:\/\/www\.javdatabase\.com\/idols\/[^"]*"[^>]*>([^<]+)<\/a>/g;
    let am;
    while ((am = re.exec(seg)) !== null) {
      const n = am[1].trim();
      if (n && !actress.includes(n)) actress.push(n);
    }
  }
  // 类别：rel="tag"（去掉演员/发行商等非类别项只做粗分，全部返回由面板展示）
  const genres = [];
  const gre = /rel="tag">([^<]{1,40})</g;
  let gm;
  while ((gm = gre.exec(html)) !== null) {
    const g = gm[1].trim();
    if (g && !genres.includes(g) && genres.length < 20) genres.push(g);
  }
  const studio = pick(/Studio:\s*<\/b>[\s\S]{0,300}?rel="tag">([^<]+)</)
    || pick(/studios\/[^"]*"[^>]*rel="tag">([^<]+)</);
  const desc = pick(/<meta name="description" content="([^"]+)"/);
  return {
    code: normCode(code),
    title: title || normCode(code),
    originalTitle: shortTitle || '',
    poster: ogImage ? absUrl(ogImage, base) : '',
    date: dateStr,
    year,
    actress,
    genres,
    studio,
    overview: desc || '',
    url: base + '/movies/' + slugOf(code) + '/',
  };
}
function parseJdbLatest(html, base) {
  const out = [];
  const seen = new Set();
  const re = /<a href="(https?:\/\/[^"]*\/movies\/([a-z0-9-]+)\/)"><img src="([^"]+)"[^>]*alt="([^"]*)"/g;
  let m;
  while ((m = re.exec(html)) !== null) {
    if (seen.has(m[2])) continue;
    seen.add(m[2]);
    const altCode = (m[4].match(/([A-Za-z]{2,6}-\d{2,5})/) || [])[1] || '';
    out.push({
      id: 'javdb_movie_' + m[2],
      code: normCode(altCode || m[2]),
      title: (m[4] || m[2]).replace(/\s*JAV Movie\s*$/i, '').trim() || normCode(m[2]),
      year: 0,
      poster: absUrl(m[3], base),
    });
    if (out.length >= 60) break;
  }
  return out;
}

/* ---------------- metadata 角色 ---------------- */
const metadataActions = {
  async register(args, ctx) {
    return {
      domain: DOMAIN,
      series: false,
      name: 'JAVDB',
      version: '0.1.0',
      language: 'zh-CN',
      imageBase: '',
      capabilities: {
        search: true,
        lookup: true,
        season: false,
        genres: true,
        cast: true,
        overview: true,
        poster: true,
        premiereDate: true,
      },
      links: [
        { name: 'JAVDB', url: 'https://javdb.com/search?q={id}&f=all' },
      ],
    };
  },

  async search(args, ctx) {
    const kw = String(args.keyword || args.wd || args.query || '').trim();
    if (!kw) return { ok: false, error: { code: 'BAD_INPUT', message: '缺少搜索词' } };
    const cfg = readSettings(ctx);
    const page = Math.max(1, parseInt(args.page, 10) || 1);
    const isCode = /^[A-Za-z]{2,6}-\d{2,5}$/.test(kw);

    // ① 先试 javdb.com
    try {
      const url = baseUrl(cfg) + '/search?q=' + encodeURIComponent(kw) + '&f=all&page=' + page;
      const { status, text } = await fetchText(url, baseUrl(cfg) + '/');
      if (isCfBlock(status, text)) throw cfErr(url);
      if (status === 200) {
        const items = parseJavdbSearch(text)
          .filter((it) => it.code)
          .map((it) => ({
            entryId: it.code,
            type: 'movie',
            title: it.title,
            year: '',
            overview: '',
            posterPath: it.poster,
          }));
        // 番号精确命中置顶
        if (isCode) {
          const hit = items.find((it) => it.entryId === normCode(kw));
          const rest = items.filter((it) => it.entryId !== normCode(kw));
          return { ok: true, list: hit ? [hit, ...rest] : items };
        }
        return { ok: true, list: items };
      }
    } catch (e) {
      if (e.code === 'CF_BLOCKED' || e.code === 'FETCH_FAILED') {
        ctx.log('javdb.com 搜索不可用(' + e.code + ')，降级到镜像源');
      } else throw e;
    }

    // ② 降级：javdatabase.com
    const mbase = mirrorUrl(cfg);
    const { status, text } = await fetchText(
      mbase + '/?s=' + encodeURIComponent(kw), mbase + '/'
    );
    if (status !== 200) {
      throw err('UPSTREAM_FAIL', '镜像源搜索失败: HTTP ' + status);
    }
    const items = parseJdbSearch(text, mbase).map((it) => ({
      entryId: it.code,
      type: 'movie',
      title: it.title,
      year: '',
      overview: '',
      posterPath: it.poster,
    }));
    return { ok: true, list: items };
  },

  async lookup(args, ctx) {
    const code = normCode(args.entryId || args.id || '');
    if (!code) return { ok: false, error: { code: 'BAD_INPUT', message: '缺少 entryId（番号）' } };
    const cfg = readSettings(ctx);
    const mbase = mirrorUrl(cfg);

    // 详情走已实测的 javdatabase.com
    const { status, text } = await fetchText(mbase + '/movies/' + slugOf(code) + '/', mbase + '/');
    if (status === 404) {
      return { ok: false, error: { code: 'NOT_FOUND', message: '未找到该番号: ' + code } };
    }
    if (status !== 200) {
      throw err('UPSTREAM_FAIL', '详情页请求失败: HTTP ' + status);
    }
    const d = parseJdbDetail(text, mbase, code);
    const premiereDate = d.date ? d.date + 'T00:00:00.0000000Z' : '';
    return {
      ok: true,
      entryId: code,
      type: 'movie',
      title: d.title,
      originalTitle: d.originalTitle,
      year: d.year,
      premiereDate,
      searchTitle: code,
      overview: d.overview,
      posterPath: d.poster,
      backdropPath: '',
      genres: d.genres,
      cast: d.actress.map((n) => ({ name: n })),
      studio: d.studio,
    };
  },

  // 电影式：无分集，如实返回空
  async season(args, ctx) {
    return { ok: true, episodes: [] };
  },

  async http(args, ctx) {
    return httpShared(args, ctx);
  },
};

/* ---------------- home 角色 ---------------- */
const ROWS = [
  { id: 'daily', title: 'JAVDB 日排行', collectionType: 'movies', cacheDuration: 1800 },
  { id: 'weekly', title: 'JAVDB 周排行', collectionType: 'movies', cacheDuration: 3600 },
  { id: 'monthly', title: 'JAVDB 月排行', collectionType: 'movies', cacheDuration: 3600 },
  { id: 'latest', title: 'JAVDB 最新影片', collectionType: 'movies', cacheDuration: 1800 },
];

const homeActions = {
  async rows(args, ctx) {
    return {
      ok: true,
      rows: ROWS.map((r) => ({
        id: r.id, title: r.title,
        collectionType: r.collectionType, cacheDuration: r.cacheDuration,
      })),
    };
  },

  async run(args, ctx) {
    const rowId = String(args.rowId || '');
    const startIndex = Math.max(0, parseInt(args.startIndex, 10) || 0);
    const limit = Math.max(1, Math.min(100, parseInt(args.limit, 10) || 20));
    const cfg = readSettings(ctx);

    let raw = [];
    if (rowId === 'latest') {
      raw = await runLatest(cfg, ctx);
    } else if (['daily', 'weekly', 'monthly'].includes(rowId)) {
      raw = await runRanking(cfg, rowId); // 被墙则如实抛 CF_BLOCKED
    } else {
      throw err('BAD_INPUT', '未知行: ' + rowId);
    }

    const items = raw.slice(startIndex, startIndex + limit).map((it) => ({
      id: it.id,
      type: 'movie',
      title: it.title,
      year: it.year || 0,
      overview: '',
      poster: it.poster,
      providerIds: it.code ? { [DOMAIN]: it.code } : {},
    }));
    return { items, total: raw.length };
  },

  async http(args, ctx) {
    return httpShared(args, ctx);
  },
};

async function runRanking(cfg, period) {
  const url = baseUrl(cfg) + '/rankings/' + period;
  const { status, text } = await fetchText(url, baseUrl(cfg) + '/');
  if (isCfBlock(status, text)) throw cfErr(url);
  if (status !== 200) throw err('UPSTREAM_FAIL', '榜单请求失败: HTTP ' + status);
  return parseJavdbRanking(text);
}

async function runLatest(cfg, ctx) {
  // 先试 javdb.com 首页
  try {
    const b = baseUrl(cfg);
    const { status, text } = await fetchText(b + '/', b + '/');
    if (isCfBlock(status, text)) throw cfErr(b);
    if (status === 200) {
      const items = parseJavdbRanking(text);
      if (items.length) return items;
    }
  } catch (e) {
    if (e.code !== 'CF_BLOCKED' && e.code !== 'FETCH_FAILED' && e.code !== 'UPSTREAM_FAIL') throw e;
    ctx.log('javdb.com 首页不可用(' + e.code + ')，降级到镜像源最新');
  }
  // 降级：javdatabase.com 首页最新
  const mbase = mirrorUrl(cfg);
  const { status, text } = await fetchText(mbase + '/', mbase + '/');
  if (status !== 200) throw err('UPSTREAM_FAIL', '镜像源首页请求失败: HTTP ' + status);
  return parseJdbLatest(text, mbase);
}

/* ---------------- webui 通道（两角色共用） ---------------- */
async function httpShared(args, ctx) {
  const method = String(args.method || 'GET').toUpperCase();
  const p = String(args.path || '/').replace(/\/+$/, '') || '/';
  if (p === '/settings' && method === 'GET') {
    const s = readSettings(ctx);
    return { body: { baseUrl: s.baseUrl || 'https://javdb.com', mirrorUrl: s.mirrorUrl || 'https://www.javdatabase.com' } };
  }
  if (p === '/save' && method === 'POST') {
    let body = {};
    try { body = JSON.parse(args.body || '{}'); } catch { /* ignore */ }
    const next = readSettings(ctx);
    if (body.baseUrl !== undefined) next.baseUrl = String(body.baseUrl || '').trim();
    if (body.mirrorUrl !== undefined) next.mirrorUrl = String(body.mirrorUrl || '').trim();
    writeSettings(ctx, next);
    return { body: { ok: true } };
  }
  return { status: 404, body: { ok: false, error: 'no route' } };
}

module.exports = {
  actions: {
    metadata: metadataActions,
    home: homeActions,
  },
};
