'use strict';
/**
 * MissAV 源插件。
 *
 * 契约：framework/contracts/contract-source.md
 * 动作：sites / search / detail / play / probe / http / home(rows/run)
 *
 * 模型：单组（default）单站（missav），两层式（directLines=false）。
 * ref 形状：`missav/<base64url(JSON)>`，JSON = { t:'missav', v:vod_id, f:flag, e:playId }
 */
const fs = require('fs');
const path = require('path');
const { search, detail, listByPath, HOSTS, UA } = require('./lib/missav');

const PLUGIN_ID = 'missav';
const SITE_KEY = 'missav';
const SITE_NAME = 'MissAV';
const FLAG = 'MissAV';

function encodeRef(body) {
  return PLUGIN_ID + '/' + Buffer.from(JSON.stringify(body), 'utf8').toString('base64url');
}
function decodeRef(ref) {
  const s = String(ref || '');
  const want = PLUGIN_ID + '/';
  if (!s.startsWith(want)) return null;
  try {
    const o = JSON.parse(Buffer.from(s.slice(want.length), 'base64url').toString('utf8'));
    return (o && typeof o === 'object' && o.t) ? o : null;
  } catch { return null; }
}

function err(code, message) {
  return { ok: false, error: { code, message: String(message || code) } };
}

const actions = {
  async sites(args, ctx) {
    return {
      sources: [{
        id: 'default', name: SITE_NAME, url: HOSTS[0],
        mode: 'remote', enabled: true, ok: true, ms: 0, siteCount: 1,
      }],
      sites: [{
        key: SITE_KEY, name: SITE_NAME, api: 'missav',
        searchable: true, source: 'default', directLines: false,
      }],
    };
  },

  async search(args, ctx) {
    const wd = String(args.wd || '').trim();
    const page = Math.max(1, parseInt(args.page, 10) || 1);
    if (!wd) return { ok: true, status: 200, json: { list: [] } };
    try {
      const list = await search(wd, page);
      return { ok: true, status: 200, json: { list }, source: 'default', site: SITE_KEY };
    } catch (e) {
      return err('UPSTREAM_ERROR', e.message);
    }
  },

  async detail(args, ctx) {
    const id = String(args.id || '');
    if (!id) return err('BAD_ARGS', '缺少 id');
    try {
      const d = await detail(id);
      if (!d) return err('NOT_FOUND', '详情取不到');
      const playId = d.m3u8 || d.vod_id;
      const item = {
        flag: FLAG, name: '正片', id: playId, index: 0, matchedBy: 'item',
        ref: encodeRef({ t: SITE_KEY, v: d.vod_id, f: FLAG, e: playId }),
      };
      const line = {
        flag: FLAG, playVia: 'client',
        episodes: [{ name: '正片', id: playId, index: 0 }],
        items: [item], target: item,
      };
      const out = {
        vodId: d.vod_id, vod_id: d.vod_id,
        name: d.vod_name, vod_name: d.vod_name,
        pic: d.vod_pic, vod_pic: d.vod_pic,
        lines: [line], lineCount: 1,
        pick: 'items', target: item,
      };
      return { ok: true, status: 200, json: { list: [out] }, detail: out };
    } catch (e) {
      return err('UPSTREAM_ERROR', e.message);
    }
  },

  async play(args, ctx) {
    const o = decodeRef(args.ref);
    if (!o) return err('BAD_REF', '认不出这个 ref');
    const url = String(o.e || '');
    if (!/^https?:\/\//i.test(url)) return err('NO_PLAY_URL', '没有可播地址');
    return {
      ok: true, status: 200,
      urls: [url],
      header: { 'User-Agent': UA, 'Referer': HOSTS[0] + '/' },
      parse: 0,
    };
  },

  async probe(args, ctx) {
    const t0 = Date.now();
    try {
      const list = await search('SSIS', 1);
      return { ok: list.length > 0, ms: Date.now() - t0, count: list.length };
    } catch (e) {
      return { ok: false, ms: Date.now() - t0, error: e.message };
    }
  },

  async http(args, ctx) {
    const dataDir = (ctx && ctx.dataDir) || path.join(__dirname, 'data');
    const sf = path.join(dataDir, 'settings.json');
    const readSettings = () => {
      try { return JSON.parse(fs.readFileSync(sf, 'utf8')); } catch { return {}; }
    };
    if (args.path === '/save' && args.method === 'POST') {
      try {
        fs.mkdirSync(dataDir, { recursive: true });
        fs.writeFileSync(sf, JSON.stringify(JSON.parse(args.body || '{}'), null, 2));
        return { body: { ok: true } };
      } catch (e) { return { status: 500, body: { ok: false, error: e.message } }; }
    }
    if (args.path === '/settings') return { body: readSettings() };
    return { status: 404, body: { ok: false, error: 'no route' } };
  },
};


/* ---------------- home 角色（Emby 实例首页） ---------------- */
// 行定义：全部是 missav.fans 真实存在的分类页，2026-10-18 实测有数据
const HOME_ROWS = [
  { id: 'new',              title: '最新更新',   path: '/cn/new',               collectionType: 'movies', cacheDuration: 1800 },
  { id: 'chinese-subtitle', title: '中文字幕',   path: '/cn/chinese-subtitle',   collectionType: 'movies', cacheDuration: 3600 },
  { id: 'fc2',              title: 'FC2',        path: '/cn/fc2',                collectionType: 'movies', cacheDuration: 3600 },
  { id: 'amateur',          title: '素人',       path: '/cn/genres/amateur',     collectionType: 'movies', cacheDuration: 3600 },
  { id: 'siro',             title: 'SIRO',       path: '/cn/siro',               collectionType: 'movies', cacheDuration: 3600 },
  { id: 'luxu',             title: 'LUXU',       path: '/cn/luxu',               collectionType: 'movies', cacheDuration: 3600 },
  { id: 'gana',             title: 'GANA',       path: '/cn/gana',               collectionType: 'movies', cacheDuration: 3600 },
  { id: 'maan',             title: 'MIUM',       path: '/cn/maan',               collectionType: 'movies', cacheDuration: 3600 },
  { id: 'ara',              title: 'ARA',        path: '/cn/ara',                collectionType: 'movies', cacheDuration: 3600 },
  { id: 'heyzo',            title: 'HEYZO无码',  path: '/cn/heyzo',              collectionType: 'movies', cacheDuration: 3600 },
  { id: 'caribbeancom',     title: '加勒比无码', path: '/cn/caribbeancom',       collectionType: 'movies', cacheDuration: 3600 },
  { id: '1pondo',           title: '一本道无码', path: '/cn/1pondo',             collectionType: 'movies', cacheDuration: 3600 },
  { id: '10musume',         title: '天然素人无码', path: '/cn/10musume',         collectionType: 'movies', cacheDuration: 3600 },
  { id: 'pacopacomama',     title: '帕考帕考妈妈', path: '/cn/pacopacomama',     collectionType: 'movies', cacheDuration: 3600 },
];
const HOME_ROW_MAP = Object.fromEntries(HOME_ROWS.map((r) => [r.id, r]));

const homeActions = {
  async rows(args, ctx) {
    return {
      ok: true,
      rows: HOME_ROWS.map((r) => ({
        id: r.id, title: r.title,
        collectionType: r.collectionType, cacheDuration: r.cacheDuration,
      })),
    };
  },

  async run(args, ctx) {
    const rowId = String(args.rowId || '');
    const row = HOME_ROW_MAP[rowId];
    if (!row) return { ok: false, error: { code: 'BAD_INPUT', message: '未知行: ' + rowId } };
    // Emby 传 startIndex（条目偏移）；missav 按页抓，每页 12 条
    const startIndex = Math.max(0, parseInt(args.startIndex, 10) || 0);
    const limit = Math.max(1, Math.min(100, parseInt(args.limit, 10) || 24));
    const PER_PAGE = 12;
    const startPage = Math.floor(startIndex / PER_PAGE) + 1;
    const endPage = Math.floor((startIndex + limit - 1) / PER_PAGE) + 1;

    let raw = [];
    for (let p = startPage; p <= endPage && raw.length < startIndex + limit; p++) {
      const list = await listByPath(row.path, p);
      if (!list.length) break;
      raw = raw.concat(list);
    }
    const slice = raw.slice(startIndex, startIndex + limit);
    const items = slice.map((it) => ({
      // id 用 missav 自己的 vod_id（详情页 URL），点进去直接调本插件 detail/play
      id: it.vod_id,
      type: 'movie',
      title: it.vod_name,
      year: 0,
      overview: it.vod_remarks || '',
      poster: it.vod_pic || '',
      providerIds: { missav: it.vod_id },
    }));
    return { ok: true, items, total: raw.length >= startIndex + limit ? startIndex + limit + 1 : raw.length };
  },
};

actions.home = homeActions;

module.exports = { actions };
