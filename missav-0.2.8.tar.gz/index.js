'use strict';
/**
 * MissAV 源插件。
 *
 * 契约：framework/contracts/contract-source.md
 * 动作：sites / search / detail / play / probe / http / home(rows/run)
 *
 * 模型：单组（default）单站（missav），两层式（directLines=false）。
 * ref 形状：`missav/<base64url(JSON)>`，JSON = { t:'missav', v:vod_id, f:flag, e:playId }
 */
const fs = require('fs');
const path = require('path');
const { search, detail, listByPath, canonicalSlug, HOSTS, UA } = require('./lib/missav');

const PLUGIN_ID = 'missav';
const SITE_KEY = 'missav';
const SITE_NAME = 'MissAV';
const FLAG = 'MissAV';

/* ---------------- 图片代理设置 ---------------- */
// mrstcdn.store 在部分地区网络不可达时，把封面经 CF Worker 中转。
// 默认已内置用户部署好的 Worker 地址（重启不丢）；在插件设置页填入其他地址可覆盖。
const DEFAULT_IMG_PROXY = 'https://missav-emby.li768435813.workers.dev';
function readSettings(ctx) {
  try {
    const dataDir = (ctx && ctx.dataDir) || path.join(__dirname, 'data');
    return JSON.parse(fs.readFileSync(path.join(dataDir, 'settings.json'), 'utf8'));
  } catch { return {}; }
}
function proxyPic(pic, ctx) {
  if (!pic) return pic;
  let proxy = DEFAULT_IMG_PROXY;
  try {
    const saved = String(readSettings(ctx).imgProxy || '').trim().replace(/\/$/, '');
    if (saved) proxy = saved; // 设置页有填就用填的
  } catch {}
  if (/\.mrstcdn\.store\//i.test(pic)) {
    return proxy + '/img?url=' + encodeURIComponent(pic);
  }
  return pic;
}

function encodeRef(body) {
  return PLUGIN_ID + '/' + Buffer.from(JSON.stringify(body), 'utf8').toString('base64url');
}
function decodeRef(ref) {
  const s = String(ref || '');
  const want = PLUGIN_ID + '/';
  if (!s.startsWith(want)) return null;
  try {
    const o = JSON.parse(Buffer.from(s.slice(want.length), 'base64url').toString('utf8'));
    return (o && typeof o === 'object' && o.t) ? o : null;
  } catch { return null; }
}

function err(code, message) {
  return { ok: false, error: { code, message: String(message || code) } };
}

const actions = {
  async sites(args, ctx) {
    return {
      sources: [{
        id: 'default', name: SITE_NAME, url: HOSTS[0],
        mode: 'remote', enabled: true, ok: true, ms: 0, siteCount: 1,
      }],
      sites: [{
        key: SITE_KEY, name: SITE_NAME, api: 'missav',
        searchable: true, source: 'default', directLines: false,
      }],
    };
  },

  async search(args, ctx) {
    const wd = String(args.wd || '').trim();
    const page = Math.max(1, parseInt(args.page, 10) || 1);
    if (!wd) return { ok: true, status: 200, json: { list: [] } };
    try {
      const list = (await search(wd, page)).map((it) => ({ ...it, vod_pic: proxyPic(it.vod_pic, ctx) }));
      return { ok: true, status: 200, json: { list }, source: 'default', site: SITE_KEY };
    } catch (e) {
      return err('UPSTREAM_ERROR', e.message);
    }
  },

  async detail(args, ctx) {
    const id = String(args.id || '');
    if (!id) return err('BAD_ARGS', '缺少 id');
    try {
      const d = await detail(id);
      if (!d) return err('NOT_FOUND', '详情取不到');
      const playId = d.m3u8 || d.vod_id;
      const item = {
        flag: FLAG, name: '正片', id: playId, index: 0, matchedBy: 'item',
        ref: encodeRef({ t: SITE_KEY, v: d.vod_id, f: FLAG, e: playId }),
      };
      const line = {
        flag: FLAG, playVia: 'client',
        episodes: [{ name: '正片', id: playId, index: 0 }],
        items: [item], target: item,
      };
      const out = {
        vodId: d.vod_id, vod_id: d.vod_id,
        name: d.vod_name, vod_name: d.vod_name,
        pic: proxyPic(d.vod_pic, ctx), vod_pic: proxyPic(d.vod_pic, ctx),
        lines: [line], lineCount: 1,
        pick: 'items', target: item,
      };
      return { ok: true, status: 200, json: { list: [out] }, detail: out };
    } catch (e) {
      return err('UPSTREAM_ERROR', e.message);
    }
  },

  async play(args, ctx) {
    const o = decodeRef(args.ref);
    if (!o) return err('BAD_REF', '认不出这个 ref');
    const url = String(o.e || '');
    if (!/^https?:\/\//i.test(url)) return err('NO_PLAY_URL', '没有可播地址');
    return {
      ok: true, status: 200,
      urls: [url],
      header: { 'User-Agent': UA, 'Referer': HOSTS[0] + '/' },
      parse: 0,
    };
  },

  async probe(args, ctx) {
    const t0 = Date.now();
    try {
      const list = await search('SSIS', 1);
      return { ok: list.length > 0, ms: Date.now() - t0, count: list.length };
    } catch (e) {
      return { ok: false, ms: Date.now() - t0, error: e.message };
    }
  },

  async http(args, ctx) {
    const dataDir = (ctx && ctx.dataDir) || path.join(__dirname, 'data');
    const sf = path.join(dataDir, 'settings.json');
    const p = String(args.path || '/').replace(/\/+$/, '') || '/';
    const method = String(args.method || 'GET').toUpperCase();
    if ((p === '/save' || p === '/api/save') && method === 'POST') {
      try {
        let body = {};
        try { body = JSON.parse(args.body || '{}'); } catch { /* ignore */ }
        const next = readSettings(ctx);
        if (body.imgProxy !== undefined) next.imgProxy = String(body.imgProxy || '').trim();
        fs.mkdirSync(dataDir, { recursive: true });
        fs.writeFileSync(sf, JSON.stringify(next, null, 2));
        return { body: { ok: true } };
      } catch (e) { return { status: 500, body: { ok: false, error: e.message } }; }
    }
    if (p === '/settings' || p === '/api/settings') {
      return { body: { imgProxy: readSettings(ctx).imgProxy || '' } };
    }
    return { status: 404, body: { ok: false, error: 'no route' } };
  },
};


/* ---------------- home 角色（Emby 实例首页） ---------------- */
// 行定义：与 mira-cat 的 py_missav spider 分类完全一致（dmXXX 前缀为 missav 真实路径）
// 2026-10-18 实测 8 个分类在 missav.fans 全部 HTTP 200 且有数据
const HOME_ROWS = [
  { id: 'chinese-subtitle', title: '中文字幕', path: '/dm278/cn/chinese-subtitle', collectionType: 'movies', cacheDuration: 3600 },
  { id: 'new',              title: '最近更新', path: '/dm539/cn/new',              collectionType: 'movies', cacheDuration: 1800 },
  { id: 'release',          title: '新作上市', path: '/dm634/cn/release',          collectionType: 'movies', cacheDuration: 1800 },
  { id: 'uncensored-leak',  title: '无码流出', path: '/dm817/cn/uncensored-leak',  collectionType: 'movies', cacheDuration: 3600 },
  { id: 'weekly-hot',       title: '本周热门', path: '/dm170/cn/weekly-hot',      collectionType: 'movies', cacheDuration: 3600 },
  { id: 'monthly-hot',      title: '本月热门', path: '/dm270/cn/monthly-hot',      collectionType: 'movies', cacheDuration: 3600 },
  { id: 'fc2',              title: 'FC2',      path: '/dm541/cn/fc2',              collectionType: 'movies', cacheDuration: 3600 },
  { id: 'madou',            title: '麻豆',     path: '/dm63/cn/madou',             collectionType: 'movies', cacheDuration: 3600 },
];
const HOME_ROW_MAP = Object.fromEntries(HOME_ROWS.map((r) => [r.id, r]));

const homeActions = {
  async rows(args, ctx) {
    return {
      ok: true,
      rows: HOME_ROWS.map((r) => ({
        id: r.id, title: r.title,
        collectionType: r.collectionType, cacheDuration: r.cacheDuration,
      })),
    };
  },

  async run(args, ctx) {
    const rowId = String(args.rowId || '');
    const row = HOME_ROW_MAP[rowId];
    if (!row) return { ok: false, error: { code: 'BAD_INPUT', message: '未知行: ' + rowId } };
    // Emby 传 startIndex（条目偏移）；missav 按页抓，每页 12 条
    const startIndex = Math.max(0, parseInt(args.startIndex, 10) || 0);
    const limit = Math.max(1, Math.min(100, parseInt(args.limit, 10) || 24));
    const PER_PAGE = 12;
    const startPage = Math.floor(startIndex / PER_PAGE) + 1;
    const endPage = Math.floor((startIndex + limit - 1) / PER_PAGE) + 1;

    let raw = [];
    for (let p = startPage; p <= endPage && raw.length < startIndex + limit; p++) {
      const list = await listByPath(row.path, p);
      if (!list.length) break;
      raw = raw.concat(list);
    }
    const slice = raw.slice(startIndex, startIndex + limit);
    const items = slice.map((it) => ({
      // 面板契约：home 条目 id 必须是 {域}_{编号}_{tv|movie} 格式，
      // 否则 Emby 点条目时 parseItemId 认不出 → routes.js:458 直接回 501。
      // （之前用完整 URL 做 id，这就是 501 的根因）
      id: `missav_${it.vod_id}_movie`,
      type: 'movie',
      title: it.vod_name,
      year: 0,
      overview: it.vod_remarks || '',
      poster: proxyPic(it.vod_pic || '', ctx),
      providerIds: { missav: it.vod_id },
    }));
    return { ok: true, items, total: raw.length >= startIndex + limit ? startIndex + limit + 1 : raw.length };
  },
};

actions.home = homeActions;

/* ---------------- metadata 角色（Emby 搜索域 + 首页点播链路） ---------------- */
// 让 missav 出现在 Emby 实例的"搜索域"中，并支撑从 home 行点条目进详情时的
// metadata/lookup 解析。entryId 直接使用 missav 详情页 URL（与 home/detail 共用）。
const DOMAIN = 'missav';
const metadataActions = {
  async register(args, ctx) {
    return {
      domain: DOMAIN,
      series: false,
      name: 'MissAV',
      version: '0.2.5',
      language: 'zh-CN',
      imageBase: '',
      capabilities: {
        search: true,
        lookup: true,
        season: false,
        genres: false,
        cast: false,
        overview: true,
        poster: true,
        premiereDate: false,
      },
      links: [],
    };
  },

  async search(args, ctx) {
    const kw = String(args.keyword || args.wd || args.query || '').trim();
    if (!kw) return { ok: true, list: [] };
    const page = Math.max(1, parseInt(args.page, 10) || 1);
    try {
      const list = await search(kw, page);
      return {
        ok: true,
        list: list.map((it) => ({
          entryId: it.vod_id,
          type: 'movie',
          title: it.vod_name,
          year: '',
          overview: it.vod_remarks || '',
          posterPath: proxyPic(it.vod_pic || '', ctx),
        })),
      };
    } catch (e) {
      return err('UPSTREAM_ERROR', e.message);
    }
  },

  async lookup(args, ctx) {
    const entryId = String(args.entryId || args.id || '').trim();
    if (!entryId) return { ok: false, error: { code: 'BAD_INPUT', message: '缺少 entryId' } };
    try {
      const d = await detail(entryId);
      if (!d) return { ok: false, error: { code: 'NOT_FOUND', message: '未找到: ' + entryId } };
      return {
        ok: true,
        entryId: d.vod_id,
        type: 'movie',
        title: d.vod_name,
        originalTitle: '',
        year: '',
        premiereDate: '',
        searchTitle: d.vod_name,
        overview: '',
        posterPath: proxyPic(d.vod_pic || '', ctx),
        backdropPath: '',
        genres: [],
        cast: [],
        studio: '',
      };
    } catch (e) {
      return err('UPSTREAM_ERROR', e.message);
    }
  },

  async season(args, ctx) {
    return { ok: true, episodes: [] };
  },
};

actions.metadata = metadataActions;

module.exports = { actions };
